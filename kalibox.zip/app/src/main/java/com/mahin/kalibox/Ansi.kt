package com.mahin.kalibox

import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan

object Palette {
    val bg = Color.parseColor("#0B0B0B")
    val panel = Color.parseColor("#161616")
    val line = Color.parseColor("#242424")
    val fg = Color.parseColor("#D4D4D4")
    val dim = Color.parseColor("#7A7A7A")
    val accent = Color.parseColor("#7EE787")
    val warn = Color.parseColor("#FF7B72")

    val ansi = intArrayOf(
        Color.parseColor("#2B2B2B"), Color.parseColor("#E5534B"),
        Color.parseColor("#57AB5A"), Color.parseColor("#C69026"),
        Color.parseColor("#4F8CC9"), Color.parseColor("#B083F0"),
        Color.parseColor("#39C5CF"), Color.parseColor("#D4D4D4"),
        Color.parseColor("#6B6B6B"), Color.parseColor("#FF7B72"),
        Color.parseColor("#7EE787"), Color.parseColor("#E3B341"),
        Color.parseColor("#79C0FF"), Color.parseColor("#D2A8FF"),
        Color.parseColor("#56D4DD"), Color.parseColor("#FFFFFF")
    )
}

/**
 * Tiny ANSI/VT parser: keeps text + 16/256/true colors + bold, understands
 * "clear screen", and silently drops every other escape sequence.
 */
class AnsiBuffer(private val maxChars: Int = 150_000) {
    private val text = SpannableStringBuilder()
    private val run = StringBuilder()
    private val params = StringBuilder()
    private var fg = Palette.fg
    private var bold = false
    private var mode = 0 // 0 text, 1 ESC, 2 CSI, 3 OSC, 4 skip-one

    @Synchronized
    fun feed(s: CharSequence) {
        for (c in s) {
            when (mode) {
                0 -> when (c) {
                    '\u001b' -> mode = 1
                    '\r', '\u0007', '\u0000' -> {}
                    '\b' -> backspace()
                    else -> run.append(c)
                }
                1 -> when (c) {
                    '[' -> { params.setLength(0); mode = 2 }
                    ']' -> mode = 3
                    '(', ')', '*', '+' -> mode = 4
                    else -> mode = 0
                }
                2 -> if (c in '@'..'~') { csi(c); mode = 0 } else params.append(c)
                3 -> when (c) {
                    '\u0007' -> mode = 0
                    '\u001b' -> mode = 4
                }
                4 -> mode = 0
            }
        }
        flushRun()
        if (text.length > maxChars) text.delete(0, text.length - maxChars * 2 / 3)
    }

    @Synchronized
    fun appendLocal(s: String, color: Int) {
        flushRun()
        val start = text.length
        text.append(s)
        text.setSpan(ForegroundColorSpan(color), start, text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    @Synchronized fun clearAll() { run.setLength(0); text.clear() }

    @Synchronized fun snapshot(): CharSequence = SpannableStringBuilder(text)

    private fun backspace() {
        if (run.isNotEmpty()) run.setLength(run.length - 1)
        else if (text.isNotEmpty() && text[text.length - 1] != '\n') text.delete(text.length - 1, text.length)
    }

    private fun flushRun() {
        if (run.isEmpty()) return
        val start = text.length
        text.append(run)
        if (fg != Palette.fg) text.setSpan(ForegroundColorSpan(fg), start, text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (bold) text.setSpan(StyleSpan(Typeface.BOLD), start, text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        run.setLength(0)
    }

    private fun csi(cmd: Char) {
        when (cmd) {
            'm' -> sgr()
            'J' -> {
                val p = params.toString()
                if (p == "2" || p == "3") { run.setLength(0); text.clear() }
            }
            else -> {}
        }
    }

    private fun sgr() {
        flushRun()
        val p: List<Int> = if (params.isEmpty()) listOf(0) else params.split(';').map { it.toIntOrNull() ?: 0 }
        var i = 0
        while (i < p.size) {
            val n = p[i]
            when {
                n == 0 -> { fg = Palette.fg; bold = false }
                n == 1 -> bold = true
                n == 22 -> bold = false
                n in 30..37 -> fg = Palette.ansi[n - 30]
                n in 90..97 -> fg = Palette.ansi[n - 90 + 8]
                n == 39 -> fg = Palette.fg
                n == 38 || n == 48 -> {
                    val isFg = n == 38
                    if (i + 2 < p.size && p[i + 1] == 5) {
                        if (isFg) fg = color256(p[i + 2])
                        i += 2
                    } else if (i + 4 < p.size && p[i + 1] == 2) {
                        if (isFg) fg = Color.rgb(p[i + 2].coerceIn(0, 255), p[i + 3].coerceIn(0, 255), p[i + 4].coerceIn(0, 255))
                        i += 4
                    }
                }
            }
            i++
        }
    }

    private fun cube(x: Int) = if (x == 0) 0 else 55 + x * 40

    private fun color256(raw: Int): Int {
        val n = raw.coerceIn(0, 255)
        return when {
            n < 16 -> Palette.ansi[n]
            n < 232 -> { val v = n - 16; Color.rgb(cube(v / 36), cube((v / 6) % 6), cube(v % 6)) }
            else -> { val g = 8 + (n - 232) * 10; Color.rgb(g, g, g) }
        }
    }
}
