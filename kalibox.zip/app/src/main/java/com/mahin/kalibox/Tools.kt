package com.mahin.kalibox

data class Tool(val cat: String, val name: String, val desc: String, val cmd: String)

private fun inst(pkg: String) = "apt install -y $pkg || (apt update && apt install -y $pkg)"

val TOOLS = listOf(
    Tool("system", "update & upgrade", "refresh package lists, upgrade everything", "apt update && apt full-upgrade -y"),
    Tool("system", "os info", "show Kali release details", "cat /etc/os-release"),
    Tool("system", "disk usage", "free space inside Kali", "df -h /"),

    Tool("essentials", "kali-linux-headless", "full CLI toolset (very large)", inst("kali-linux-headless")),
    Tool("essentials", "top 10", "the classic ten Kali tools", inst("kali-tools-top10")),
    Tool("essentials", "nano", "simple text editor", inst("nano")),
    Tool("essentials", "vim", "text editor", inst("vim")),
    Tool("essentials", "git", "version control", inst("git")),
    Tool("essentials", "curl + wget", "download things", inst("curl wget")),
    Tool("essentials", "python3-pip", "python packages", inst("python3-pip")),
    Tool("essentials", "tmux", "split / persistent terminals", inst("tmux")),
    Tool("essentials", "htop", "process viewer", inst("htop")),

    Tool("recon", "nmap", "network scanner", inst("nmap")),
    Tool("recon", "masscan", "very fast port scanner", inst("masscan")),
    Tool("recon", "whois + dig", "domain and DNS lookups", inst("whois dnsutils")),
    Tool("recon", "theHarvester", "emails, hosts, subdomains from OSINT", inst("theharvester")),
    Tool("recon", "dnsrecon", "DNS enumeration", inst("dnsrecon")),
    Tool("recon", "amass", "attack-surface mapping", inst("amass")),

    Tool("web", "sqlmap", "SQL injection testing", inst("sqlmap")),
    Tool("web", "nikto", "web server scanner", inst("nikto")),
    Tool("web", "gobuster", "directory / DNS brute-force", inst("gobuster")),
    Tool("web", "ffuf", "fast web fuzzer", inst("ffuf")),
    Tool("web", "whatweb", "identify web technologies", inst("whatweb")),
    Tool("web", "wpscan", "WordPress scanner", inst("wpscan")),

    Tool("exploit", "metasploit", "exploit framework (large)", inst("metasploit-framework")),
    Tool("exploit", "searchsploit", "offline Exploit-DB search", inst("exploitdb")),

    Tool("passwords", "john", "John the Ripper", inst("john")),
    Tool("passwords", "hydra", "online login brute-forcer", inst("hydra")),
    Tool("passwords", "hashcat", "hash cracker (CPU only here)", inst("hashcat")),
    Tool("passwords", "hashid", "identify hash types", inst("hashid")),
    Tool("passwords", "wordlists", "rockyou and friends", inst("wordlists")),

    Tool("network", "netcat", "the network swiss-army knife", inst("netcat-traditional")),
    Tool("network", "tcpdump", "packet capture (limited without root)", inst("tcpdump")),
    Tool("network", "traceroute", "trace network path", inst("traceroute")),
    Tool("network", "smbclient + enum4linux", "SMB / Windows shares", inst("smbclient enum4linux")),
    Tool("network", "proxychains + tor", "route traffic through Tor", inst("proxychains4 tor")),

    Tool("forensics", "binwalk", "firmware analysis", inst("binwalk")),
    Tool("forensics", "exiftool", "file metadata", inst("libimage-exiftool-perl")),
    Tool("forensics", "foremost", "file carving", inst("foremost"))
)
