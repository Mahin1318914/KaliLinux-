package com.mahin.kalibox

import android.system.Os
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.tukaani.xz.XZInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.net.URL

object Installer {
    const val ROOTFS_URL =
        "https://kali.download/nethunter-images/current/rootfs/kali-nethunter-rootfs-minimal-arm64.tar.xz"

    fun isInstalled(rootfs: File) =
        File(rootfs, "usr/bin/bash").exists() || File(rootfs, "bin/bash").exists()

    /** Blocking. status(message, percent 0..100) is called from this thread. */
    fun install(cacheDir: File, rootfs: File, status: (String, Int) -> Unit) {
        val archive = File(cacheDir, "kali.tar.xz")
        val part = File(rootfs.parentFile, "kali.part")
        wipe(part)

        // 1) download (0..50 %)
        status("Downloading Kali", 0)
        val conn = URL(ROOTFS_URL).openConnection()
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        val total = conn.contentLengthLong
        conn.getInputStream().use { inp ->
            FileOutputStream(archive).use { fo ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                var last = -1
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    fo.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val pct = (done * 50 / total).toInt()
                        if (pct != last) { last = pct; status("Downloading Kali  ${done shr 20} MB", pct) }
                    }
                }
            }
        }

        // 2) extract (50..100 %)
        val size = archive.length().coerceAtLeast(1)
        var consumed = 0L
        val counting = object : FilterInputStream(BufferedInputStream(FileInputStream(archive), 1 shl 16)) {
            override fun read(): Int {
                val r = super.read()
                if (r >= 0) consumed++
                return r
            }
            override fun read(b: ByteArray, off: Int, len: Int): Int {
                val r = super.read(b, off, len)
                if (r > 0) consumed += r
                return r
            }
        }
        part.mkdirs()
        var lastPct = -1
        TarArchiveInputStream(XZInputStream(counting)).use { tar ->
            var e: TarArchiveEntry? = tar.nextTarEntry
            while (e != null) {
                val name = e.name.substringAfter('/', "")
                if (name.isNotEmpty() && name.split('/').none { it == ".." }) {
                    val f = File(part, name)
                    when {
                        e.isDirectory -> {
                            f.mkdirs()
                            try { Os.chmod(f.path, (e.mode and 511) or 448) } catch (_: Exception) {}
                        }
                        e.isSymbolicLink -> {
                            f.parentFile?.mkdirs()
                            f.delete()
                            try { Os.symlink(e.linkName, f.path) } catch (_: Exception) {}
                        }
                        e.isLink -> {
                            val target = File(part, e.linkName.substringAfter('/', ""))
                            f.parentFile?.mkdirs()
                            if (target.exists()) target.copyTo(f, overwrite = true)
                        }
                        e.isFile -> {
                            f.parentFile?.mkdirs()
                            FileOutputStream(f).use { tar.copyTo(it) }
                            try { Os.chmod(f.path, (e.mode and 511) or 384) } catch (_: Exception) {}
                        }
                    }
                }
                val pct = 50 + (consumed * 50 / size).toInt().coerceAtMost(50)
                if (pct != lastPct) { lastPct = pct; status("Extracting", pct) }
                e = tar.nextTarEntry
            }
        }
        archive.delete()

        wipe(rootfs)
        if (!part.renameTo(rootfs)) throw IllegalStateException("could not move rootfs into place")
        File(rootfs, "tmp").mkdirs()
        status("Done", 100)
    }

    /** rm -rf without following symlinks (Android toybox rm). */
    fun wipe(dir: File) {
        if (!dir.exists()) return
        try {
            ProcessBuilder("rm", "-rf", dir.path).redirectErrorStream(true).start().waitFor()
        } catch (_: Exception) {
        }
    }
}
