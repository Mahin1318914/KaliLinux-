package com.mahin.kalibox

import android.app.Activity
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import java.io.File

/**
 * KaliBox: minimal, Linux-feeling UI.
 *   terminal  - persistent bash session + extra-key row
 *   tools     - searchable one-tap installers for common Kali tools
 *   settings  - font size, restart, update, reset
 */
class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private val tabList = arrayListOf(Tab())
    private var curIdx = 0
    private val cur: Tab get() = tabList[curIdx]
    private val ansi: AnsiBuffer get() = cur.ansi
    private val rootfs by lazy { File(filesDir, "kali") }
    private val prefs by lazy { getSharedPreferences("kalibox", MODE_PRIVATE) }

    private lateinit var out: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var progressLabel: TextView

    private val panels = ArrayList<View>()
    private val tabs = ArrayList<TextView>()
    private var session: ShellSession?
        get() = cur.session
        set(v) { cur.session = v }
    private lateinit var tabBar: LinearLayout
    private var ctrlOn = false
    private var ctrlBtn: TextView? = null
    private var installing = false
    private var fontSp = 12f
    private var renderPending = false
    private var guard = false

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fontSp = prefs.getFloat("font", 12f)
        window.statusBarColor = Palette.bg
        window.navigationBarColor = Palette.bg
        setContentView(buildRoot())
        show(0)
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(
                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                ), 1
            )
        }
        if (prefs.getBoolean("keepalive", true)) setKeepAlive(true)
        note("kalibox  -  rootless Kali in a sandbox\n", Palette.accent)
        note("nothing outside this app is touched. uninstall = gone.\n\n")
        if (Installer.isInstalled(rootfs)) startShell() else runInstall()
    }

    override fun onDestroy() {
        tabList.forEach { it.session?.stop() }
        super.onDestroy()
    }

    // Volume Down = sticky Ctrl (like Termux)
    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        if (keyCode == android.view.KeyEvent.KEYCODE_VOLUME_DOWN) {
            ctrlOn = !ctrlOn
            ctrlBtn?.setTextColor(if (ctrlOn) Palette.accent else Palette.fg)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun setKeepAlive(on: Boolean) {
        val i = android.content.Intent(this, KeepAliveService::class.java)
        try {
            if (on) {
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            } else {
                stopService(i)
            }
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------ layout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun mono(s: String, sp: Float, color: Int): TextView = TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(color)
        typeface = Typeface.MONOSPACE
    }

    private fun chip(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(6).toFloat()
    }

    private fun divider() = View(this).apply { setBackgroundColor(Palette.line) }

    private fun buildRoot(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Palette.bg)
            fitsSystemWindows = true
        }
        root.addView(buildHeader())

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
            progressTintList = ColorStateList.valueOf(Palette.accent)
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(4)))
        progressLabel = mono("", 11f, Palette.dim).apply {
            visibility = View.GONE
            setPadding(dp(14), dp(4), dp(14), dp(4))
        }
        root.addView(progressLabel)
        root.addView(divider(), LinearLayout.LayoutParams(-1, 1))

        val content = FrameLayout(this)
        listOf(buildTerminal(), buildTools(), buildSettings()).forEach {
            panels.add(it)
            content.addView(it, FrameLayout.LayoutParams(-1, -1))
        }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }

    private fun buildHeader(): View {
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(6), dp(14), dp(6))
        }
        listOf("terminal", "tools", "settings").forEachIndexed { i, n ->
            val t = mono(n, 13f, Palette.dim).apply {
                setPadding(0, dp(8), dp(18), dp(8))
                setOnClickListener { show(i) }
            }
            tabs.add(t)
            h.addView(t)
        }
        h.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        status = mono("", 11f, Palette.dim)
        h.addView(status)
        return h
    }

    private fun show(i: Int) {
        panels.forEachIndexed { idx, p -> p.visibility = if (idx == i) View.VISIBLE else View.GONE }
        tabs.forEachIndexed { idx, t ->
            val sel = idx == i
            t.setTextColor(if (sel) Palette.accent else Palette.dim)
            t.setTypeface(Typeface.MONOSPACE, if (sel) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    private fun setStatus(s: String, color: Int) {
        status.text = s
        status.setTextColor(color)
    }

    // ------------------------------------------------------------ terminal tab

    private fun buildTerminal(): View {
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        out = mono("", fontSp, Palette.fg).apply {
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setTextIsSelectable(true)
        }
        scroll = ScrollView(this).apply { addView(out) }
        p.addView(buildTabBar())
        p.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        p.addView(divider(), LinearLayout.LayoutParams(-1, 1))
        p.addView(buildShortcuts())
        p.addView(buildKeys())
        p.addView(buildInputRow())
        return p
    }

    private fun buildKeys(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(6), dp(8), dp(2))
        }
        fun key(label: String, action: (TextView) -> Unit): TextView {
            val t = mono(label, 12f, Palette.fg).apply {
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(8), dp(12), dp(8))
                background = chip(Palette.panel)
            }
            t.setOnClickListener { action(t) }
            row.addView(t, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) })
            return t
        }
        key("esc") { send("\u001b") }
        key("tab") { flushInput(); send("\t") }
        ctrlBtn = key("ctrl") {
            ctrlOn = !ctrlOn
            it.setTextColor(if (ctrlOn) Palette.accent else Palette.fg)
        }
        key("^C") { send("\u0003") }
        key("^D") { send("\u0004") }
        key("^L") { send("\u000c") }
        key("paste") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!t.isNullOrEmpty()) { flushInput(); send(t) }
        }
        key("↑") { flushInput(); send("\u001b[A") }
        key("↓") { flushInput(); send("\u001b[B") }
        key("←") { flushInput(); send("\u001b[D") }
        key("→") { flushInput(); send("\u001b[C") }
        for (c in listOf("/", "-", "|", "~", ".", "*", "&", ">")) key(c) { input.append(c) }
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
        }
    }

    private fun buildInputRow(): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(2), dp(8), dp(8))
        }
        r.addView(mono("›", 18f, Palette.accent).apply { setPadding(0, 0, dp(8), 0) })
        input = EditText(this).apply {
            setTextColor(Palette.fg)
            setHintTextColor(Palette.dim)
            hint = "type a command"
            typeface = Typeface.MONOSPACE
            textSize = 14f
            background = null
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
                InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            imeOptions = EditorInfo.IME_ACTION_SEND or EditorInfo.IME_FLAG_NO_EXTRACT_UI
            setOnEditorActionListener { _, _, _ -> sendLine(); true }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    // sticky CTRL: next typed character becomes a control code
                    if (!ctrlOn || guard || s == null || s.isEmpty()) return
                    val ch = s[s.length - 1]
                    guard = true
                    s.clear()
                    guard = false
                    ctrlOn = false
                    ctrlBtn?.setTextColor(Palette.fg)
                    val code = ch.uppercaseChar().code and 0x1f
                    send(code.toChar().toString())
                }
            })
        }
        r.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(mono("⏎", 18f, Palette.accent).apply {
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { sendLine() }
        })
        return r
    }

    // ------------------------------------------------------------ tabs

    private fun buildTabBar(): View {
        tabBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(10), dp(2), dp(10), dp(2))
        }
        refreshTabBar()
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(tabBar)
        }
    }

    private fun refreshTabBar() {
        tabBar.removeAllViews()
        tabList.forEachIndexed { i, _ ->
            val sel = i == curIdx
            tabBar.addView(mono("${i + 1}", 12f, if (sel) Palette.accent else Palette.dim).apply {
                setPadding(dp(12), dp(6), dp(12), dp(6))
                setTypeface(Typeface.MONOSPACE, if (sel) Typeface.BOLD else Typeface.NORMAL)
                setOnClickListener { switchTab(i) }
                setOnLongClickListener { closeTab(i); true }
            })
        }
        tabBar.addView(mono("+", 14f, Palette.accent).apply {
            setPadding(dp(12), dp(4), dp(12), dp(4))
            setOnClickListener { newTab() }
        })
        tabBar.addView(mono("hold a number to close", 10f, Palette.dim).apply {
            setPadding(dp(8), dp(8), 0, 0)
        })
    }

    private fun switchTab(i: Int) {
        curIdx = i
        refreshTabBar()
        out.text = ansi.snapshot()
        scroll.post { scroll.scrollTo(0, scroll.getChildAt(0).height) }
        val s = session
        if (s != null && s.running) setStatus("● bash m${prefs.getInt("proot_mode", 0)}", Palette.accent)
        else setStatus("stopped", Palette.warn)
    }

    private fun newTab() {
        if (!Installer.isInstalled(rootfs)) { note("Kali is not installed yet\n", Palette.warn); return }
        tabList.add(Tab())
        curIdx = tabList.size - 1
        refreshTabBar()
        out.text = ansi.snapshot()
        startShell()
    }

    private fun closeTab(i: Int) {
        if (tabList.size == 1) { note("can't close the last tab\n"); return }
        tabList[i].session?.stop()
        tabList.removeAt(i)
        if (i < curIdx) curIdx-- else if (curIdx >= tabList.size) curIdx = tabList.size - 1
        switchTab(curIdx)
    }

    // ------------------------------------------------------------ shortcut box

    private val defaultShortcuts = listOf(
        "ls -la", "pwd", "clear", "whoami", "uname -a", "ip a", "df -h",
        "apt update", "apt upgrade -y", "ping -c 4 8.8.8.8"
    )
    private var shortcuts = mutableListOf<String>()
    private lateinit var shortcutRow: LinearLayout
    private lateinit var shortcutBody: View

    private fun loadShortcuts() {
        val raw = prefs.getString("shortcuts", null)
        shortcuts = try {
            if (raw == null) defaultShortcuts.toMutableList()
            else { val a = JSONArray(raw); MutableList(a.length()) { a.getString(it) } }
        } catch (_: Exception) {
            defaultShortcuts.toMutableList()
        }
    }

    private fun saveShortcuts() {
        prefs.edit().putString("shortcuts", JSONArray(shortcuts).toString()).apply()
    }

    private fun buildShortcuts(): View {
        loadShortcuts()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), dp(8), 0)
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = mono("shortcuts", 11f, Palette.dim)
        head.addView(title, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        val add = mono("+", 18f, Palette.accent).apply {
            setPadding(dp(14), dp(2), dp(14), dp(2))
            setOnClickListener { editShortcut(-1) }
        }
        val toggle = mono("×", 18f, Palette.dim).apply { setPadding(dp(14), dp(2), dp(10), dp(2)) }
        head.addView(add)
        head.addView(toggle)

        shortcutRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        shortcutBody = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(shortcutRow)
        }

        fun applyCollapsed(c: Boolean) {
            shortcutBody.visibility = if (c) View.GONE else View.VISIBLE
            add.visibility = if (c) View.GONE else View.VISIBLE
            toggle.text = if (c) "▴" else "×"
            title.text = if (c) "shortcuts (tap ▴ to open)" else "shortcuts"
        }
        toggle.setOnClickListener {
            val collapse = shortcutBody.visibility == View.VISIBLE
            prefs.edit().putBoolean("sc_collapsed", collapse).apply()
            applyCollapsed(collapse)
        }
        applyCollapsed(prefs.getBoolean("sc_collapsed", false))

        box.addView(head)
        box.addView(shortcutBody)
        refreshShortcuts()
        return box
    }

    private fun refreshShortcuts() {
        shortcutRow.removeAllViews()
        if (shortcuts.isEmpty()) {
            shortcutRow.addView(mono("empty - tap + to add a command", 12f, Palette.dim).apply {
                setPadding(dp(6), dp(8), dp(6), dp(8))
            })
            return
        }
        shortcuts.forEachIndexed { i, cmd ->
            val c = mono(cmd, 12f, Palette.fg).apply {
                setPadding(dp(12), dp(8), dp(12), dp(8))
                background = chip(Palette.panel)
                setOnClickListener { runShortcut(cmd) }
                setOnLongClickListener { shortcutMenu(i); true }
            }
            shortcutRow.addView(c, LinearLayout.LayoutParams(-2, -2).apply {
                marginEnd = dp(6)
                topMargin = dp(4)
            })
        }
    }

    private fun runShortcut(cmd: String) {
        val s = session
        if (s == null || !s.running) {
            note("shell is not running - press enter first\n", Palette.warn)
            return
        }
        flushInput()
        s.send(cmd + "\n")
    }

    private fun shortcutMenu(i: Int) {
        val cmd = shortcuts[i]
        AlertDialog.Builder(this)
            .setTitle(cmd)
            .setItems(arrayOf("Run", "Insert (don't run)", "Edit", "Delete")) { _, which ->
                when (which) {
                    0 -> runShortcut(cmd)
                    1 -> { input.setText(cmd); input.setSelection(input.text.length); input.requestFocus() }
                    2 -> editShortcut(i)
                    3 -> { shortcuts.removeAt(i); saveShortcuts(); refreshShortcuts() }
                }
            }
            .show()
    }

    private fun editShortcut(i: Int) {
        val et = EditText(this).apply {
            typeface = Typeface.MONOSPACE
            hint = "e.g. nmap -sV 192.168.1.1"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            if (i >= 0) { setText(shortcuts[i]); setSelection(text.length) }
            setPadding(dp(24), dp(16), dp(24), dp(16))
        }
        AlertDialog.Builder(this)
            .setTitle(if (i < 0) "New shortcut" else "Edit shortcut")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) {
                    if (i < 0) shortcuts.add(t) else shortcuts[i] = t
                    saveShortcuts()
                    refreshShortcuts()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------ tools tab

    private fun buildTools(): View {
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, dp(14), dp(24))
        }
        fun fill(q: String) {
            list.removeAllViews()
            var cat = ""
            for (t in TOOLS) {
                if (q.isNotBlank() && !(t.name + " " + t.desc + " " + t.cat).contains(q, ignoreCase = true)) continue
                if (t.cat != cat) {
                    cat = t.cat
                    list.addView(mono(cat, 11f, Palette.dim).apply { setPadding(0, dp(18), 0, dp(2)) })
                }
                list.addView(toolRow(t))
            }
        }
        val search = EditText(this).apply {
            hint = "search tools"
            setHintTextColor(Palette.dim)
            setTextColor(Palette.fg)
            typeface = Typeface.MONOSPACE
            textSize = 13f
            background = chip(Palette.panel)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { fill(s?.toString() ?: "") }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        fill("")
        p.addView(search, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(10), dp(14), dp(4)) })
        p.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        return p
    }

    private fun toolRow(t: Tool): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
            setOnClickListener { confirmRun(t) }
        }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(mono(t.name, 14f, Palette.fg))
        left.addView(mono(t.desc, 11f, Palette.dim))
        r.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(mono(if (t.cmd.startsWith("apt install")) "install" else "run", 12f, Palette.accent))
        return r
    }

    private fun confirmRun(t: Tool) {
        AlertDialog.Builder(this)
            .setTitle(t.name)
            .setMessage("Runs in the terminal:\n\n${t.cmd}")
            .setPositiveButton("Run") { _, _ -> runInTerminal(t.cmd) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------ settings tab

    private fun buildSettings(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(24))
        }

        val fontValue = mono("${fontSp.toInt()} sp", 13f, Palette.fg)
        fun bump(d: Float) {
            fontSp = (fontSp + d).coerceIn(8f, 22f)
            out.textSize = fontSp
            fontValue.text = "${fontSp.toInt()} sp"
            prefs.edit().putFloat("font", fontSp).apply()
        }
        fun stepper(label: String, d: Float) = mono(label, 18f, Palette.accent).apply {
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener { bump(d) }
        }
        val fontRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(12))
        }
        fontRow.addView(mono("font size", 14f, Palette.fg), LinearLayout.LayoutParams(0, -2, 1f))
        fontRow.addView(stepper("−", -1f))
        fontRow.addView(fontValue)
        fontRow.addView(stepper("+", 1f))
        col.addView(fontRow)
        col.addView(divider(), LinearLayout.LayoutParams(-1, 1))

        col.addView(settingRow("restart shell", "start a fresh bash session") { restartShell() })
        col.addView(divider(), LinearLayout.LayoutParams(-1, 1))
        col.addView(settingRow("proot mode", "fix tests for 'cd: Function not implemented' (restarts shell)") { pickProotMode() })
        col.addView(divider(), LinearLayout.LayoutParams(-1, 1))
        col.addView(settingRow("self-test", "run cd / pwd / ls checks in the terminal") {
            runInTerminal("echo T1; cd / && pwd; echo T2; cd /root && pwd; echo T3; ls / | head -3; echo T4; mkdir -p /tmp/t && cd /tmp/t && pwd; cd /root; echo done")
        })
        col.addView(divider(), LinearLayout.LayoutParams(-1, 1))
        col.addView(settingRow("keep alive", "notification + wake lock so HyperOS does not kill the shell (tap to toggle)") {
            val on = !prefs.getBoolean("keepalive", true)
            prefs.edit().putBoolean("keepalive", on).apply()
            setKeepAlive(on)
            note("keep alive: ${if (on) "on" else "off"}\n")
        })
        col.addView(divider(), LinearLayout.LayoutParams(-1, 1))
        col.addView(settingRow("clear screen", "wipe the terminal output") { ansi.clearAll(); render() })
        col.addView(divider(), LinearLayout.LayoutParams(-1, 1))
        col.addView(settingRow("reset shortcuts", "restore the default shortcut list") {
            shortcuts = defaultShortcuts.toMutableList()
            saveShortcuts()
            refreshShortcuts()
        })
        col.addView(divider(), LinearLayout.LayoutParams(-1, 1))
        col.addView(settingRow("update kali", "apt update && apt full-upgrade") {
            runInTerminal("apt update && apt full-upgrade -y")
        })
        col.addView(divider(), LinearLayout.LayoutParams(-1, 1))
        col.addView(settingRow("reset kali", "delete the whole install and download it again", true) { confirmReset() })
        col.addView(divider(), LinearLayout.LayoutParams(-1, 1))

        col.addView(mono(
            "rootless proot sandbox\n" +
                "- no monitor mode / packet injection\n" +
                "- full-screen apps (nano, vim, htop) are not supported yet\n" +
                "- phone storage is at /sdcard inside Kali (allow the storage permission)\n" +
                "- Volume Down = sticky Ctrl, '+' next to the tab numbers opens a new tab\n" +
                "- data lives in: ${rootfs.path}\n" +
                "- HyperOS: set battery to 'no restrictions' for KaliBox",
            11f, Palette.dim
        ).apply { setPadding(0, dp(20), 0, 0) })
        return ScrollView(this).apply { addView(col) }
    }

    private fun settingRow(title: String, sub: String, danger: Boolean = false, action: () -> Unit): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, dp(12))
            setOnClickListener { action() }
        }
        c.addView(mono(title, 14f, if (danger) Palette.warn else Palette.fg))
        c.addView(mono(sub, 11f, Palette.dim))
        return c
    }

    // ------------------------------------------------------------ actions

    private fun send(s: String) { session?.send(s) }

    private fun flushInput() {
        val t = input.text.toString()
        if (t.isNotEmpty()) { input.text.clear(); send(t) }
    }

    private fun sendLine() {
        val t = input.text.toString()
        input.text.clear()
        val s = session
        if (s == null || !s.running) {
            if (!installing) { if (Installer.isInstalled(rootfs)) startShell() else runInstall() }
            return
        }
        s.send(t + "\n")
    }

    private fun runInTerminal(cmd: String) {
        val s = session
        if (s == null || !s.running) { note("shell is not running - press enter in the terminal first\n", Palette.warn); show(0); return }
        show(0)
        flushInput()
        s.send(cmd + "\n")
    }

    private fun restartShell() {
        session?.stop()
        session = null
        note("\n--- restarting shell ---\n")
        show(0)
        startShell()
    }

    private fun pickProotMode() {
        val names = arrayOf(
            "0  default (current)",
            "1  no -w /root",
            "2  seccomp acceleration on",
            "3  userland proot binary",
            "4  userland + no -w"
        )
        AlertDialog.Builder(this)
            .setTitle("proot mode (now: ${prefs.getInt("proot_mode", 0)})")
            .setItems(names) { _, which ->
                prefs.edit().putInt("proot_mode", which).apply()
                note("\n--- proot mode $which ---\n")
                restartShell()
            }
            .show()
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Reset Kali?")
            .setMessage("Deletes everything inside Kali (installed tools, your files) and downloads it again.")
            .setPositiveButton("Reset") { _, _ -> doReset() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun doReset() {
        tabList.forEach { it.session?.stop(); it.session = null }
        show(0)
        note("\n--- resetting Kali ---\n", Palette.warn)
        setStatus("resetting", Palette.dim)
        Thread {
            Installer.wipe(rootfs)
            ui.post { ansi.clearAll(); render(); runInstall() }
        }.start()
    }

    // ------------------------------------------------------------ install / shell

    private fun runInstall() {
        installing = true
        setStatus("installing", Palette.dim)
        progress.progress = 0
        progress.visibility = View.VISIBLE
        progressLabel.visibility = View.VISIBLE
        note("first run: downloading Kali (big file, use Wi-Fi)\n")
        Thread {
            try {
                Installer.install(cacheDir, rootfs) { msg, pct ->
                    ui.post { progress.progress = pct; progressLabel.text = "$msg  $pct%" }
                }
                ui.post {
                    installing = false
                    progress.visibility = View.GONE
                    progressLabel.visibility = View.GONE
                    note("kali installed.\n\n", Palette.accent)
                    startShell()
                }
            } catch (e: Exception) {
                ui.post {
                    installing = false
                    progress.visibility = View.GONE
                    progressLabel.visibility = View.GONE
                    setStatus("not installed", Palette.warn)
                    note("install failed: ${e.message}\npress enter to retry.\n", Palette.warn)
                }
            }
        }.start()
    }

    private fun startShell() {
        val t = cur
        out.post {
            val usable = out.width - out.paddingLeft - out.paddingRight
            val cols = (usable / out.paint.measureText("M")).toInt().coerceIn(40, 200)
            val s = ShellSession(
                this, rootfs,
                { txt -> t.ansi.feed(txt); ui.post { if (t === cur) render() } },
                { code ->
                    ui.post {
                        t.ansi.appendLocal("\n[shell exited ($code) - press enter to restart]\n", Palette.warn)
                        if (t === cur) { setStatus("stopped", Palette.warn); render() }
                    }
                }
            )
            val err = s.start(cols, 40)
            if (err != null) {
                setStatus("error", Palette.warn)
                note(err, Palette.warn)
            } else {
                t.session = s
                if (t === cur) setStatus("● bash m${prefs.getInt("proot_mode", 0)}", Palette.accent)
            }
        }
    }

    // ------------------------------------------------------------ output

    private fun note(s: String, color: Int = Palette.dim) {
        ansi.appendLocal(s, color)
        render()
    }

    private fun render() {
        if (renderPending) return
        renderPending = true
        ui.postDelayed({
            renderPending = false
            val child = scroll.getChildAt(0)
            val atBottom = child == null || child.bottom - (scroll.height + scroll.scrollY) < dp(80)
            out.text = ansi.snapshot()
            if (atBottom) scroll.post { scroll.scrollTo(0, scroll.getChildAt(0).height) }
        }, 40)
    }
}
