package com.mahin.kalibox

import android.content.Context
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.concurrent.Executors

/** One persistent bash session inside the Kali rootfs (via proot). */
class ShellSession(
    private val ctx: Context,
    private val rootfs: File,
    private val onOutput: (String) -> Unit,
    private val onExit: (Int) -> Unit
) {
    private var proc: Process? = null
    private var stdin: OutputStream? = null
    private val writer = Executors.newSingleThreadExecutor()
    @Volatile private var stopped = false

    val running: Boolean get() = proc?.isAlive == true

    /** Returns an error message, or null when the shell started. */
    fun start(cols: Int, rows: Int): String? {
        val lib = File(ctx.applicationInfo.nativeLibraryDir)
        // proot test modes (Settings -> proot mode):
        // 0 default | 1 no -w | 2 seccomp on | 3 userland binary | 4 userland + no -w
        val mode = ctx.getSharedPreferences("kalibox", Context.MODE_PRIVATE).getInt("proot_mode", 0)
        val userland = (mode == 3 || mode == 4) && File(lib, "libproot-userland.so").exists()
        val proot = File(lib, if (userland) "libproot-userland.so" else "libproot.so")
        val loader = File(lib, "libproot-loader.so")
        if (!proot.exists()) {
            return "[!] libproot.so not found. Put the proot binaries in app/src/main/jniLibs/arm64-v8a/ (see README) and rebuild.\n"
        }

        File(rootfs, "root").mkdirs()
        File(rootfs, "tmp").mkdirs()
        File(rootfs, "sdcard").mkdirs()
        File(rootfs, "root/.kalibox_rc").writeText(RC)
        File(rootfs, "etc").mkdirs()
        File(rootfs, "etc/resolv.conf").writeText("nameserver 1.1.1.1\nnameserver 8.8.8.8\n")
        // apt cannot drop privileges inside Android's sandbox (setresuid fails)
        File(rootfs, "etc/apt/apt.conf.d").mkdirs()
        File(rootfs, "etc/apt/apt.conf.d/99kalibox").writeText("APT::Sandbox::User \"root\";\n")

        // `script` gives bash a real pty (colors, readline history, Ctrl-C).
        val inner = "stty cols $cols rows $rows; exec bash --rcfile /root/.kalibox_rc -i"
        val launch = "if command -v script >/dev/null 2>&1; then exec script -qfc '$inner' /dev/null; " +
            "else exec bash --rcfile /root/.kalibox_rc -i; fi"

        val cmd = listOf(
            proot.path, "--kill-on-exit", "--link2symlink", "-0", "-r", rootfs.path,
            "-b", "/dev", "-b", "/proc", "-b", "/sys",
            "-b", "${File(rootfs, "tmp").path}:/dev/shm"
        ) + (if (File("/storage/emulated/0").exists()) listOf("-b", "/storage/emulated/0:/sdcard") else emptyList()) +(if (mode == 1 || mode == 4) emptyList() else listOf("-w", "/root")) + listOf(
            "/usr/bin/env", "-i",
            "HOME=/root", "TERM=xterm-256color", "LANG=C.UTF-8",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "/bin/bash", "-c", launch
        )
        val pb = ProcessBuilder(cmd).redirectErrorStream(true)
        pb.environment().apply {
            put("PROOT_LOADER", loader.path)
            put("PROOT_TMP_DIR", ctx.cacheDir.path)
            if (mode != 2) put("PROOT_NO_SECCOMP", "1")
        }
        return try {
            val p = pb.start()
            proc = p
            stdin = p.outputStream
            Thread {
                try {
                    val r = InputStreamReader(p.inputStream, Charsets.UTF_8)
                    val buf = CharArray(4096)
                    while (true) {
                        val n = r.read(buf)
                        if (n < 0) break
                        onOutput(String(buf, 0, n))
                    }
                } catch (_: Exception) {
                }
                val code = try { p.waitFor() } catch (_: InterruptedException) { -1 }
                if (!stopped) onExit(code)
            }.start()
            null
        } catch (e: Exception) {
            "[!] could not start shell: ${e.message}\n"
        }
    }

    fun send(s: String) {
        writer.execute {
            try {
                stdin?.write(s.toByteArray(Charsets.UTF_8))
                stdin?.flush()
            } catch (_: Exception) {
            }
        }
    }

    fun stop() {
        stopped = true
        try { proc?.destroy() } catch (_: Exception) {}
        writer.shutdown()
    }

    companion object {
        private val RC = """
            [ -f /etc/bash.bashrc ] && . /etc/bash.bashrc
            export DEBIAN_FRONTEND=noninteractive
            export LS_COLORS='di=1;34:ln=36:ex=1;32'
            alias ls='ls --color=auto'
            alias ll='ls -lah --color=auto'
            alias grep='grep --color=auto'
            alias pkg='apt'
            PS1='\[\e[1;32m\]kali\[\e[0m\]@\[\e[1;34m\]box\[\e[0m\] \[\e[1;36m\]\w\[\e[0m\] \$ '
        """.trimIndent() + "\n"
    }
}
