# KaliBox

Rootless Kali Linux in an Android app (proot sandbox). Nothing in HyperOS/system is changed. Uninstall = everything gone.

## UI
- **terminal**: persistent bash session, colors, shortcut box (+ to add your own, long-press to edit/delete, x to collapse), extra-key row (esc, tab, ctrl, ^C, ^D, ^L, arrows, symbols).
- **tools**: searchable one-tap installers (nmap, sqlmap, metasploit, hydra, ...).
- **settings**: font size, restart shell, reset shortcuts, update Kali, reset Kali.

## Build
proot is already bundled (app/src/main/jniLibs/arm64-v8a). See PROOT-LICENSE.txt.
- PC: open this folder in Android Studio, Build -> Build APK(s).
- No PC: upload kalibox.zip + .github/workflows/build.yml to a GitHub repo; Actions builds the APK.

## Notes
- targetSdk is 28 on purpose: Android 10+ blocks running binaries from app data for newer targets. Sideload only.
- First launch downloads the minimal Kali rootfs (about 2 GB free needed).
- Rootless limits: no Wi-Fi monitor mode / packet injection / kernel-level tools.
- Full-screen terminal apps (nano, vim, htop) are not rendered correctly yet.
- HyperOS: set battery to "no restrictions" for KaliBox.
