#!/bin/bash
# Builds the NEWER Termux proot (has the fix for "cd: Function not implemented" on
# recent Android kernels) as app/src/main/jniLibs/arm64-v8a/libproot-new.so.
# Any failure is harmless: the app falls back to the bundled older proot.
cd "$(dirname "$0")"
ROOT="$PWD"

NDK="${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_HOME:-$ANDROID_NDK_ROOT}}"
if [ -z "$NDK" ] || [ ! -d "$NDK" ]; then
  echo "[build-proot] no NDK found, skipping (old proot will be used)"
  exit 0
fi

(
  set -e
  TC="$NDK/toolchains/llvm/prebuilt/linux-x86_64"
  export CC="$TC/bin/aarch64-linux-android24-clang"
  export AR="$TC/bin/llvm-ar" RANLIB="$TC/bin/llvm-ranlib" STRIP="$TC/bin/llvm-strip"
  export OBJCOPY="$TC/bin/llvm-objcopy" OBJDUMP="$TC/bin/llvm-objdump"

  # talloc's old waf needs python <= 3.11
  P="$(ls -d /opt/hostedtoolcache/Python/3.9*/x64/bin /opt/hostedtoolcache/Python/3.10*/x64/bin /opt/hostedtoolcache/Python/3.11*/x64/bin 2>/dev/null | head -1)"
  if [ -n "$P" ]; then export PATH="$P:$PATH"; fi
  python3 --version

  W="$ROOT/.pbuild"
  rm -rf "$W"; mkdir -p "$W"; cd "$W"
  git clone --depth 1 https://github.com/green-green-avk/build-proot-android helper
  git clone --depth 1 https://github.com/termux/proot termux-proot
  curl -fsSL https://download.samba.org/pub/talloc/talloc-2.1.14.tar.gz | tar xz

  STATIC="$W/static"; mkdir -p "$STATIC/include" "$STATIC/lib"
  cd talloc-2.1.14
  cat > cross-answers.txt <<'EOF'
Checking uname sysname type: "Linux"
Checking uname machine type: "dontcare"
Checking uname release type: "dontcare"
Checking uname version type: "dontcare"
Checking simple C program: OK
rpath library support: OK
-Wl,--version-script support: FAIL
Checking getconf LFS_CFLAGS: OK
Checking for large file support without additional flags: OK
Checking for -D_FILE_OFFSET_BITS=64: OK
Checking for -D_LARGE_FILES: OK
Checking correct behavior of strtoll: OK
Checking for working strptime: OK
Checking for C99 vsnprintf: OK
Checking for HAVE_SHARED_MMAP: OK
Checking for HAVE_MREMAP: OK
Checking for HAVE_INCOHERENT_MMAP: OK
Checking for HAVE_SECURE_MKSTEMP: OK
Checking getconf large file support flags work: OK
Checking for HAVE_IFACE_IFCONF: FAIL
EOF
  PATH="$W/helper/target-mock-bin:$PATH" ./configure build "--prefix=$W/inst" \
    --disable-rpath --disable-python --cross-compile --cross-answers=cross-answers.txt
  "$AR" rcs "$STATIC/lib/libtalloc.a" bin/default/talloc*.o
  cp -f talloc.h "$STATIC/include"

  cd "$W/termux-proot/src"
  sed -i '/#define HAS_LOADER_32BIT true/d' arch.h   # no 32-bit loader needed
  export CFLAGS="-I$STATIC/include -Werror=implicit-function-declaration"
  export LDFLAGS="-L$STATIC/lib"
  make V=1 proot
  "$STRIP" proot
  mkdir -p "$ROOT/app/src/main/jniLibs/arm64-v8a"
  cp proot "$ROOT/app/src/main/jniLibs/arm64-v8a/libproot-new.so"
  echo "[build-proot] OK: libproot-new.so built"
) || echo "[build-proot] FAILED, the app will use the bundled older proot"
exit 0
