package com.mahin.kalibox

/** One terminal tab: its own screen buffer and its own bash session. */
class Tab {
    val ansi = AnsiBuffer()
    var session: ShellSession? = null
}
