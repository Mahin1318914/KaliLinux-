#!/bin/bash
# Run with: NDK=... ROOT=... bash -e build-proot-inner.sh   (any failing command aborts)
set -e
TC="$NDK/toolchains/llvm/prebuilt/linux-x86_64"
export CC="$TC/bin/aarch64-linux-android24-clang"
export AR="$TC/bin/llvm-ar" RANLIB="$TC/bin/llvm-ranlib" STRIP="$TC/bin/llvm-strip"
export OBJCOPY="$TC/bin/llvm-objcopy" OBJDUMP="$TC/bin/llvm-objdump"

# talloc's old waf needs python <= 3.11
P="$(ls -d /opt/hostedtoolcache/Python/3.9*/x64/bin /opt/hostedtoolcache/Python/3.10*/x64/bin /opt/hostedtoolcache/Python/3.11*/x64/bin 2>/dev/null | head -1 || true)"
if [ -n "$P" ]; then export PATH="$P:$PATH"; fi
python3 --version

W="$ROOT/.pbuild"
rm -rf "$W"; mkdir -p "$W"; cd "$W"
git clone --depth 1 https://github.com/green-green-avk/build-proot-android helper
git clone --depth 1 https://github.com/termux/proot termux-proot
curl -fsSL https://download.samba.org/pub/talloc/talloc-2.1.14.tar.gz | tar xz

STATIC="$W/static"; mkdir -p "$STATIC/include" "$STATIC/lib"
cd talloc-2.1.14
cat > cross-answers.txt <<'EOF'
Checking uname sysname type: "Linux"
Checking uname machine type: "dontcare"
Checking uname release type: "dontcare"
Checking uname version type: "dontcare"
Checking simple C program: OK
rpath library support: OK
-Wl,--version-script support: FAIL
Checking getconf LFS_CFLAGS: OK
Checking for large file support without additional flags: OK
Checking for -D_FILE_OFFSET_BITS=64: OK
Checking for -D_LARGE_FILES: OK
Checking correct behavior of strtoll: OK
Checking for working strptime: OK
Checking for C99 vsnprintf: OK
Checking for HAVE_SHARED_MMAP: OK
Checking for HAVE_MREMAP: OK
Checking for HAVE_INCOHERENT_MMAP: OK
Checking for HAVE_SECURE_MKSTEMP: OK
Checking getconf large file support flags work: OK
Checking for HAVE_IFACE_IFCONF: FAIL
EOF
PATH="$W/helper/target-mock-bin:$PATH" ./configure build "--prefix=$W/inst" \
  --disable-rpath --disable-python --cross-compile --cross-answers=cross-answers.txt
"$AR" rcs "$STATIC/lib/libtalloc.a" bin/default/talloc*.o
cp -f talloc.h "$STATIC/include"

cd "$W/termux-proot/src"
sed -i '/#define HAS_LOADER_32BIT true/d' arch.h   # no 32-bit loader needed
# The newest NDK compiler rejects old C (missing headers etc.): pre-include the common
# headers and demote those errors to warnings.
export CFLAGS="-I$STATIC/include -include string.h -include stdlib.h -include unistd.h \
 -Wno-implicit-function-declaration -Wno-error=implicit-function-declaration \
 -Wno-error=int-conversion -Wno-error=incompatible-pointer-types \
 -Wno-error=incompatible-function-pointer-types"
export LDFLAGS="-L$STATIC/lib"
make V=1 proot
test -s proot
"$STRIP" proot
mkdir -p "$ROOT/app/src/main/jniLibs/arm64-v8a"
cp proot "$ROOT/app/src/main/jniLibs/arm64-v8a/libproot-new.so"
test -s "$ROOT/app/src/main/jniLibs/arm64-v8a/libproot-new.so"
