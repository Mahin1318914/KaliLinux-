#!/bin/bash
# Builds the NEWER Termux proot (has the fix for "cd: Function not implemented" on
# recent Android kernels) as app/src/main/jniLibs/arm64-v8a/libproot-new.so.
# Any failure is harmless: the app falls back to the bundled older proot.
cd "$(dirname "$0")"
ROOT="$PWD"

NDK="${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_HOME:-$ANDROID_NDK_ROOT}}"
if [ -z "$NDK" ] || [ ! -d "$NDK" ]; then
  echo "[build-proot] no NDK found, skipping (old proot will be used)"
  exit 0
fi

# separate bash process so that `set -e` really stops at the first failure
if NDK="$NDK" ROOT="$ROOT" bash -e ./build-proot-inner.sh; then
  echo "[build-proot] OK: libproot-new.so built"
else
  echo "[build-proot] FAILED, the app will use the bundled older proot"
fi
exit 0
